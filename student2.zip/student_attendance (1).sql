-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 11 août 2020 à 04:43
-- Version du serveur :  10.4.13-MariaDB
-- Version de PHP : 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `student_attendance`
--

-- --------------------------------------------------------

--
-- Structure de la table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `datesign` date NOT NULL DEFAULT current_timestamp(),
  `time` time NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `attendance`
--

INSERT INTO `attendance` (`id`, `iduser`, `datesign`, `time`) VALUES
(1, 1, '2020-07-22', '00:09:11'),
(2, 1, '2020-07-22', '00:00:00'),
(3, 2, '2020-07-22', '00:00:00'),
(4, 7, '2020-07-22', '12:35:57'),
(5, 8, '2020-07-27', '11:24:42'),
(6, 8, '2020-07-27', '11:46:21'),
(7, 8, '2020-07-27', '11:56:08'),
(8, 8, '2020-07-27', '12:00:29'),
(9, 8, '2020-07-27', '12:01:42'),
(10, 8, '2020-07-27', '12:02:44'),
(11, 8, '2020-07-27', '12:03:10'),
(12, 8, '2020-07-27', '12:06:43'),
(13, 8, '2020-07-27', '12:08:35'),
(14, 8, '2020-07-27', '12:09:13'),
(15, 12, '2020-07-27', '12:19:59'),
(16, 13, '2020-07-27', '12:30:39'),
(17, 13, '2020-07-27', '13:56:46'),
(18, 13, '2020-07-27', '13:56:51'),
(19, 13, '2020-07-27', '13:57:16'),
(20, 13, '2020-07-27', '13:58:05'),
(21, 13, '2020-07-27', '13:58:15'),
(22, 13, '2020-07-27', '13:58:42'),
(23, 13, '2020-07-27', '14:00:02'),
(24, 14, '2020-07-28', '19:13:39'),
(25, 5, '2020-08-02', '09:32:16'),
(26, 5, '2020-08-02', '10:37:13'),
(27, 5, '2020-08-02', '10:37:35'),
(28, 5, '2020-08-02', '10:43:11'),
(29, 5, '2020-08-02', '11:31:11'),
(30, 5, '2020-08-02', '11:40:10'),
(31, 5, '2020-08-02', '11:41:53'),
(32, 5, '2020-08-02', '11:42:51'),
(33, 17, '2020-08-10', '23:47:40'),
(34, 5, '2020-08-11', '01:20:00'),
(35, 1, '2020-08-11', '01:22:44'),
(36, 5, '2020-08-11', '01:26:48'),
(37, 5, '2020-08-11', '01:28:17'),
(38, 0, '2020-08-11', '01:30:09'),
(39, 0, '2020-08-11', '01:36:49'),
(40, 19, '2020-08-11', '01:55:37');

-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

CREATE TABLE `etudiant` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `tel` int(11) NOT NULL,
  `sex` varchar(2) NOT NULL,
  `password` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `etudiant`
--

INSERT INTO `etudiant` (`id`, `name`, `email`, `tel`, `sex`, `password`, `file_name`) VALUES
(1, 'nkflc', 'nkflc@gmail.com', 78945612, 'F', '', ''),
(2, 'azerty', 'azerty@gmail.com', 78945612, 'F', 'azerty', ''),
(3, 'chris', 'chris@gmail.com', 45785156, 'M', 'chris', ''),
(4, 'remi', 'remi@gmail.com', 2857412, 'M', 'remi', ''),
(5, 'kj', 'kj@gmail.com', 78945662, 'M', 'kj', ''),
(6, 'Emerson', 'Emerson@gmail.com', 789456, 'M', 'emerson', '');

-- --------------------------------------------------------

--
-- Structure de la table `liste`
--

CREATE TABLE `liste` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `liste`
--

INSERT INTO `liste` (`id`, `email`, `password`) VALUES
(1, 'teacher@gmail.com', '789');

-- --------------------------------------------------------

--
-- Structure de la table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `tel` int(11) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `password` varchar(15) NOT NULL,
  `file_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `student`
--

INSERT INTO `student` (`id`, `name`, `email`, `tel`, `sex`, `password`, `file_name`) VALUES
(1, 'wxcvbn', 'wxcvbn@gmail.com', 0, '', 'wxcvbn', ''),
(2, 'kat', 'kat@gmail.com', 0, '', 'kat', ''),
(3, 'qsdfgh', 'qsdfgh@gmail.com', 0, '', 'qsdfgh', ''),
(4, 'yuiop', 'yuiop@gmail.com', 0, '', 'yuiop', ''),
(5, 'pm', 'pm@gmail.com', 0, '', 'pm', ''),
(6, 'gh', 'gh@gmail.com', 0, '', 'gh', ''),
(7, 'vb', 'vb@gmail.com', 0, '', 'vb', ''),
(8, 'Kone', 'kone@gmail.com', 0, '', 'kone', ''),
(9, 'azty', 'azty@gmail.com', 0, '', 'azty', ''),
(10, 'yuuio', 'yuuio@gmail.com', 0, '', 'yuuio', ''),
(11, 'Léon Katinan ', 'lk@gmail.com', 0, '', 'lkm', ''),
(12, 'df', 'df@gmail.com', 0, '', 'df', ''),
(13, 'yao', 'yao@gmail.com', 0, '', 'yao', ''),
(14, 'avec', 'avec@gmail.com', 0, '', 'avec', ''),
(15, 'dfg', 'dff@gmail.com', 123, 'F', '123', 'empphoto/1092491.2231409.jpg'),
(16, 'dfg', 'dfg@gmail.com', 7455, 'M', '123', 'empphoto/111664banque-un-dirigeant-d-entreprise-est-il-considere-comme-un-emprunteur-averti.jpg'),
(17, 'vb', 'vbn@gmail.com', 457812, 'male', '45', 'empphoto/845659images (5).jpg'),
(18, 'Leon', 'leon@gmail.com', 123456, 'male', '123', 'empphoto/229240naruto-uzumaki-naruto-41089718-1200-800.png'),
(19, 'kat', 'kate@gmail.com', 57189766, 'male', '789', 'empphoto/778575www_3d_man_sitting_desk_headset.jpg');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `etudiant`
--
ALTER TABLE `etudiant`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `liste`
--
ALTER TABLE `liste`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT pour la table `etudiant`
--
ALTER TABLE `etudiant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `liste`
--
ALTER TABLE `liste`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
