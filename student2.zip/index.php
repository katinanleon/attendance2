<!DOCTYPE html>
<html>
<head>

	<title>Student</title>
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link rel="stylesheet" type="text/css" href="style.css">
<!------ Include the above in your HEAD tag ---------->
</head>
<body class="container bg-secondary">


    <h1 class="text-center">STUDENT ATTENDANCE</h1>

	
	<div class="container">
	<div class="row">
	
	<!--team-1-->
	<div class="col-lg-4">
	<div class="our-team-main">
	
	<div class="team-front">
	<img src="http://placehold.it/110x110/9c27b0/fff?text=login
	" class="img-fluid" />
	<h3>Student login</h3>
	
	</div>
	
	<div class="team-back">
	<span>
	<a href="loginstyle.php" class="text-info">Sign in</a>
	</span>
	</div>
	
	</div>
	</div>
	<!--team-1-->
	
	<!--team-2-->
	<div class="col-lg-4">
	<div class="our-team-main">
	
	<div class="team-front">
	<img src="http://placehold.it/110x110/336699/fff?text=Register" class="img-fluid" />
	<h3>Student register</h3>
	
	</div>
	
	<div class="team-back">
	<span>
	<a href="formulaire2.php" class="text-info">Register</a>
	</span>
	</div>
	
	</div>
	</div>
	<!--team-2-->
	
	<!--team-3-->
	<div class="col-lg-4">
	<div class="our-team-main">
	
	<div class="team-front">
	<img src="http://placehold.it/110x110/607d8b/fff?text=Teacher" class="img-fluid" />
	<h3>Teacher login</h3>
	
	</div>
	
	<div class="team-back">
	<span>
	<a href="teachlogin.php" class="text-info">TLogin</a>
	</span>
	</div>
	
	</div>
	</div>






</body>
</html>




	
	
	
	
	
	