<?php
include 'database.php';
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Signature</title>
</head>
<body>
<h1>Thank you for signing Up to day </h1>


<SCRIPT LANGUAGE="JavaScript">
var maintenant=new Date();
document.write(maintenant);
</SCRIPT>
<br>


<br>
<br>
<div>
<button type="button" class="btn btn-primary btn-lg"><a href="index.php">OK</a></button>
</div><br>


<?php
    
      
      $email = $_SESSION["email"];
      $dup = mysqli_query($conn,"select id from student where email = '$email'");
      $row = mysqli_fetch_assoc($dup);
      $id = $row["id"];

      $insertion = "INSERT INTO attendance(iduser) VALUES('$id')";
	  mysqli_query($conn, $insertion);

    //sql="select * from attendance";
    // $result= mysqli_query($db,$sql) or die("mauvaise requete");
   //  while ($row=mysqli_fetch_assoc($result)){
    // 	echo "{$row['iduser']} {$row['date']
  // {$row['time']}<br>";
    // }
	  // afficher des informations de la table attendance

 ?>
</body>
</html>